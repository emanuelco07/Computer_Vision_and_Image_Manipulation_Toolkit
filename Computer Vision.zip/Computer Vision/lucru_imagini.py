import PIL;
from PIL import Image, ImageFilter, ImageDraw, ImageFont, ImageEnhance

#Cerintele de la pasul 2

#Cerinta 1 - Sa se incarce si sa se afiseze primele 2 imagini.
file1="imagini/papagal1.jpg"
image1=Image.open(file1) #incarcam prima imagine
image1.show() #afisam prima imagine

file2 = "imagini/papagali2.jpeg"
image2=Image.open(file2) #incarcam a doua imagine
image2.show() #afisam a doua imagine

#Cerinta 2 - Sa se salveze una dintre ele cu alta extensie fata de cea initiala.
image2.save("imagini/papagali2.png") #salvam a doua imagine cu extensia .png

#Certinta 3 - Sa se roteasca o imagine in sensul acelor de ceasornic la (90-ziua nasterii fiecarui student) grade.  => 83
image_rotated = image1.rotate(-83)
image_rotated.show() #rotim prima imagine in sensul acelor de ceasornic cu 83 de grade (nu pot folosi functia display() pentru ca nu folosesc jupyter notebook)

#Cerinta 4 - Sa se aplice cate 2 filtre diferite celor 2 imagini si sa se afiseze imaginile filtrate.
image_blurred = image1.filter(ImageFilter.BLUR) #aplicam un efect de estompare primei imagini
image_blurred.show() #afisam imaginea estompata
image_edges = image1.filter(ImageFilter.FIND_EDGES)
image_edges.show()
images_emboss = image2.filter(ImageFilter.EMBOSS) #aplicam un efect emboss
images_emboss.show()
images_edge_enhance = image2.filter(ImageFilter.EDGE_ENHANCE_MORE)
images_edge_enhance.show() #afisam imaginea cu efect emboss

#Cerinta 5 - Sa se creeze o imagine noua ce contine alaturarea celor 2 imagini.
#redimensionam imagine si afisam si dimensiunile initiale ale acestora
image1_size = image1.size
image2_size = image2.size
print(image1_size)
print(image2_size)
if image2_size<image1_size:
    image1 = image1.resize((image2_size[0], image2_size[1]))
else:
    image2 = image2.resize((image1_size[0], image1_size[1]))
#salvam din in cele doua variabile noile marimi ale imaginilor
image1_size = image1.size
image2_size = image2.size
#cream noua imagine
glued_image = Image.new('RGB',(2*image1_size[0], image1_size[1]), (250,250,250))
#adaugam cele 2 imagini initiale
glued_image.paste(image1,(0,0))
glued_image.paste(image2,(image1_size[0],0))
#salvam imaginea rezultat si o afisam
glued_image.save("imagini/merged_image.jpg","JPEG")
glued_image.show()

#Cerinta 6 - Sa se decupeze un element din imagine (fata unei persoane, o floare, un animal, un obiect etc.).
cropped_image = image1.crop((700, 50, 950, 350)) #colt dreapta sus 700px (stanga-dreapta), 50px (sus-jos), colt stanga jos 950px, 400px
cropped_image.show()

#Cerinta 7 - Sa se incadreze cu un dreptunghi cu borduri albastre sau verzi elementul decupat la pasul anterior.
drawing_object=ImageDraw.Draw(image1)
drawing_object.rectangle((700, 50, 950, 350), fill = None, outline ='blue') #aceleasi coordonate ca mai sus
image1.show()

#Cerinta 8 - Sa se adauge imaginilor prenumele studentului cu urmatoarele caracteristici: 
            # - dimensiunea fontului=ziua nasterii,
            # - culoarea fontului: R=numar la alegerea studentului, G=ziua nasterii, B=luna nasterii*10
            
draw = ImageDraw.Draw(image1) #prima imagine
text = "Emanuel"
font = ImageFont.truetype('arial.ttf', 7)

#adaugarea textului 
draw.text((100,100), text, font=font,fill=(77,7,30))
image1.show()

image22 = image2.copy() #copiem imaginea 2 pentru ca vrem sa o folosim la cerinta 9
draw = ImageDraw.Draw(image22) #a doua imagine
text = "Emanuel"
font = ImageFont.truetype('arial.ttf', 7)

#adaugarea textului 
draw.text((100,100), text, font=font,fill=(70,7,30))
image22.show()

# Cerinta 9 - Sa se creeze o foaie de contact (contact sheets of images) utilizand una dintre primele doua imagini. 
        # Numarul de imagini generat este egal cu luna nasterii studentului. 
        # Daca luna nasterii < 6 atunci numarul de imagini generate va fi dublul lunii de nastere.
        # Reprezinta un bonus daca imaginile nu sunt generate dupa grade diferite de luminozitate, 
        # ci dupa alt aspect.
        
#transformam imaginea in mod RGB
image2 = image2.convert('RGB')

# se construieste o lista cu 6 imagini ce au culori diferite(de la gri la culori complexe)
enhancer=ImageEnhance.Color(image2)
images=[]
for i in range(1, 7):
    images.append(enhancer.enhance(i/6))
    
# se creeaza o foaie de contact cu imaginile de diferite luminozitati
# functia PIL.Image.new primeste ca un prim parametru tipul imaginii (in acest caz RGB)
# Pentru dimensiune se da un tuplu, care contine lățimea si inaltimea imaginii. 
# Se incearca asezarea lor ca o matrice 3X2.
# Acest lucru va face un fel de "pânză" pentru foaia de contact. 
# În cele din urmă, culoarea (al treilea parametru) este opțională și se lasa valoarea implicita (negru).
first_image=images[0]
contact_sheet=PIL.Image.new(first_image.mode, (first_image.width*3,first_image.height*2))
x=0
y=0

# se parcurge lista cu cele 6 imagini de luminozitati diferite
for img in images:
    # se adauga imaginea curenta in foaia de contact
    contact_sheet.paste(img, (x, y) )
    # Se actualizeaza valoarea parametrilor x si y ce indica pozitia. 
    #Daca s-a atins latimea imaginii, se seteaza x la 0 si y la urmatoarea linie de inserat
    if x+first_image.width == contact_sheet.width:
        x=0
        y=y+first_image.height
    else:
        x=x+first_image.width

# se redimensioneaza foaia de contact si se afiseaza
contact_sheet = contact_sheet.resize((int(contact_sheet.width/2),int(contact_sheet.height/2) ))
contact_sheet.show()