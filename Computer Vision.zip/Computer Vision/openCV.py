import cv2 as cv
import PIL
import inspect
import timeit
from PIL import ImageDraw, Image

#Trebuie utilizat XML based classifiers
face_cascade = cv.CascadeClassifier('clasificatori/haarcascade_frontalface_default.xml')
eye_cascade = cv.CascadeClassifier('clasificatori/haarcascade_eye.xml')

#Cerintele de la pasul 3
img = cv.imread('imagini/oameni.jpg') #incarcam imaginea

#Cream mai intai o functie ce deseneaza dreptunghiurile pe o imagine, pentru o modularizare cat mai eficienta a exemplului
def show_drept(faces):
    pil_img=Image.open('imagini/oameni.jpg').convert("RGB") #incarcam imaginea si o convertim la RGB
    drawing=ImageDraw.Draw(pil_img) #desenam dreptunghiurile
    for x,y,w,h in faces:
        drawing.rectangle((x,y,x+w,y+h), outline="white")
    pil_img.show() #afisam imaginea

cv_img_bin=cv.threshold(img,120,255,cv.THRESH_BINARY)[1] 
# din lista intoarsa, ne intereseaza a doua valoare

#masurarea timpului de executie a functiei detectMultiScale()
timp = timeit.timeit(lambda: face_cascade.detectMultiScale(cv_img_bin, 1.02), number=10) #nu putem folosi %timeit pentru ca suntem in vs code
faces = face_cascade.detectMultiScale(cv_img_bin,1.02)
print("Timp mediu pe apel:", timp/10, "secunde")

show_drept(faces)

#factorul de scalare miscoreaza imaginea cu 1.x% la fiecare pas din cautare